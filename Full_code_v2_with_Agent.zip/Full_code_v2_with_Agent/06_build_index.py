"""
Builds the retrieval index once, ahead of time.

Run this AFTER 01_prepare_data.py and BEFORE launching the chatbot, so the
first chat response isn't slowed down by index building.

    python 06_build_index.py
"""

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.retriever import Retriever


def main():
    print("Building retrieval index...")
    retriever = Retriever()
    # Quick sanity check.
    sample = retriever.search("What are the early signs of Alzheimer's?", top_k=2)
    print("\nSanity check - top match for an example question:")
    for r in sample:
        print(f"  score={r['score']:.3f}  Q: {r['question'][:70]}")
    print("\nIndex is ready. You can now run the chatbot.")


if __name__ == "__main__":
    main()
