from pathlib import Path
from typing import Optional

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

from src.config import (
    BASE_MODEL_NAME,
    MODEL_OUTPUT_DIR,
    MAX_NEW_TOKENS,
    TEMPERATURE,
    TOP_P,
    REPETITION_PENALTY,
)

from src.safety import (
    SafetyChecker,
    clean_model_response,
    add_medical_disclaimer,
)


SYSTEM_INSTRUCTION = (
    "You are an Alzheimer's support chatbot. "
    "Give helpful, simple, compassionate, and safe information for patients and caregivers. "
    "Use ONLY the reference information provided to answer. "
    "Do not invent facts, names, sources, or links. "
    "Do not claim to diagnose disease. "
    "Do not replace doctors. "
    "For emergencies or medication decisions, advise contacting a qualified healthcare professional."
)

# Minimum similarity for a retrieved answer to be considered relevant.
# If nothing clears this, we fall back to a safe "I don't have that" reply.
MIN_RETRIEVAL_SCORE = 0.35


class AlzheimerChatbot:
    def __init__(self, model_dir: Optional[Path] = None, use_retrieval: bool = True):
        self.model_dir = Path(model_dir) if model_dir else MODEL_OUTPUT_DIR
        self.safety_checker = SafetyChecker()
        self.use_retrieval = use_retrieval

        self.device = "cuda" if torch.cuda.is_available() else "cpu"

        if self.model_dir.exists() and any(self.model_dir.iterdir()):
            model_path = str(self.model_dir)
            print(f"Loading fine-tuned model from: {model_path}")
        else:
            model_path = BASE_MODEL_NAME
            print(
                f"Fine-tuned model not found at {self.model_dir}. "
                f"Loading base model instead: {BASE_MODEL_NAME}"
            )

        self.tokenizer = AutoTokenizer.from_pretrained(model_path)

        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        self.model = AutoModelForCausalLM.from_pretrained(model_path)
        self.model.to(self.device)
        self.model.eval()

        # Load the retriever (RAG). If it fails, we degrade gracefully to
        # plain generation rather than crashing.
        self.retriever = None
        if self.use_retrieval:
            try:
                from src.retriever import Retriever
                self.retriever = Retriever()
            except Exception as error:
                print(f"Warning: retrieval disabled ({error}). Using plain generation.")
                self.retriever = None

    def _build_context_block(self, user_input: str):
        """
        Returns (context_text, best_score). Empty context if nothing relevant.
        """
        if self.retriever is None:
            return "", 0.0

        results = self.retriever.search(user_input, top_k=3)
        if not results:
            return "", 0.0

        best_score = results[0]["score"]

        # Keep only reasonably relevant matches.
        good = [r for r in results if r["score"] >= MIN_RETRIEVAL_SCORE]
        if not good:
            return "", best_score

        lines = []
        for i, r in enumerate(good, start=1):
            lines.append(f"[{i}] {r['answer']}")
        return "\n".join(lines), best_score

    def build_prompt(self, user_input: str, context_text: str) -> str:
        if context_text:
            return (
                f"{SYSTEM_INSTRUCTION}\n\n"
                f"### Reference information:\n{context_text}\n\n"
                f"### User:\n{user_input}\n\n"
                f"### Assistant:\n"
            )
        # No context: still answer, but the instruction tells it to be cautious.
        return (
            f"{SYSTEM_INSTRUCTION}\n\n"
            f"### Reference information:\n(No specific reference found.)\n\n"
            f"### User:\n{user_input}\n\n"
            f"### Assistant:\n"
        )

    def generate_raw_response(self, prompt: str) -> str:
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=768,
        ).to(self.device)

        with torch.no_grad():
            output_ids = self.model.generate(
                **inputs,
                max_new_tokens=MAX_NEW_TOKENS,
                do_sample=True,
                temperature=TEMPERATURE,
                top_p=TOP_P,
                repetition_penalty=REPETITION_PENALTY,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )

        generated_text = self.tokenizer.decode(
            output_ids[0],
            skip_special_tokens=False,
        )

        if "### Assistant:" in generated_text:
            response = generated_text.split("### Assistant:")[-1]
        else:
            response = generated_text.replace(prompt, "")

        for stop in ["### User:", "### Reference information:", "<|endoftext|>"]:
            if stop in response:
                response = response.split(stop)[0]

        return response.strip()

    def chat(self, user_input: str) -> str:
        user_input = user_input.strip()

        if not user_input:
            return "Please type a question."

        safety_result = self.safety_checker.check(user_input)

        if not safety_result.allowed:
            return safety_result.message

        context_text, best_score = self._build_context_block(user_input)

        # If retrieval is on but found nothing relevant, prefer an honest
        # fallback over a hallucinated answer.
        if self.retriever is not None and not context_text:
            fallback = (
                "I don't have specific information about that in my knowledge base. "
                "For reliable guidance on this, please consult a qualified healthcare "
                "professional or a trusted Alzheimer's organization."
            )
            if safety_result.message:
                fallback = f"{safety_result.message}\n\n{fallback}"
            return add_medical_disclaimer(fallback)

        prompt = self.build_prompt(user_input, context_text)
        raw_answer = self.generate_raw_response(prompt)
        cleaned_answer = clean_model_response(raw_answer)

        # If the model produced almost nothing useful, fall back to the best
        # retrieved real answer directly.
        if not cleaned_answer or len(cleaned_answer) < 10:
            if context_text:
                cleaned_answer = context_text.split("\n")[0].lstrip("[1] ").strip()
            else:
                cleaned_answer = (
                    "I understand your question. Could you provide a little more detail "
                    "so I can give a more helpful general answer?"
                )

        if safety_result.message:
            cleaned_answer = f"{safety_result.message}\n\n{cleaned_answer}"

        final_answer = add_medical_disclaimer(cleaned_answer)

        return final_answer


def interactive_chat():
    chatbot = AlzheimerChatbot()

    print("\nAlzheimer's Chatbot (RAG)")
    print("Type 'exit' or 'quit' to stop.\n")

    while True:
        user_input = input("You: ").strip()

        if user_input.lower() in ["exit", "quit", "q"]:
            print("Bot: Goodbye.")
            break

        answer = chatbot.chat(user_input)
        print(f"Bot: {answer}\n")


if __name__ == "__main__":
    interactive_chat()
