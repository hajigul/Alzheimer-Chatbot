"""
Retrieval module for grounded answers (RAG).

Builds a semantic search index over the real question/answer pairs in your
dataset. At chat time we look up the most similar REAL answers and feed them
to the model as grounded context, so it stops inventing facts.

The index is built once and cached to disk under models/retriever_index/.
"""

import json
import pickle
from pathlib import Path
from typing import List, Dict

import numpy as np

from src.config import (
    PROCESSED_TRAIN_FILE,
    PROCESSED_VALIDATION_FILE,
    MODELS_DIR,
)

# Sentence-embedding model used to turn text into vectors.
# Small, fast, and good quality. Downloaded once from Hugging Face.
EMBED_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

# Where the prebuilt index is cached.
INDEX_DIR = MODELS_DIR / "retriever_index"
EMBEDDINGS_FILE = INDEX_DIR / "embeddings.npy"
RECORDS_FILE = INDEX_DIR / "records.pkl"


def _load_qa_records() -> List[Dict[str, str]]:
    """
    Loads question/answer pairs from the processed JSONL files.
    Each record has 'question' and 'answer'.
    """
    records: List[Dict[str, str]] = []

    for path in [PROCESSED_TRAIN_FILE, PROCESSED_VALIDATION_FILE]:
        if not Path(path).exists():
            continue
        with open(path, "r", encoding="utf-8") as file:
            for line in file:
                line = line.strip()
                if not line:
                    continue
                row = json.loads(line)
                question = (row.get("question") or "").strip()
                answer = (row.get("answer") or "").strip()
                if question and answer and len(answer) > 10:
                    records.append({"question": question, "answer": answer})

    if not records:
        raise RuntimeError(
            "No Q&A records found. Run 'python 01_prepare_data.py' first."
        )

    return records


class Retriever:
    """
    Semantic retriever over the dataset's real answers.
    """

    def __init__(self):
        # Imported here so the heavy dependency only loads when retrieval is used.
        from sentence_transformers import SentenceTransformer

        print(f"Loading embedding model: {EMBED_MODEL_NAME}")
        self.model = SentenceTransformer(EMBED_MODEL_NAME)

        self.records: List[Dict[str, str]] = []
        self.embeddings: np.ndarray = np.array([])

        self._load_or_build_index()

    def _load_or_build_index(self):
        if EMBEDDINGS_FILE.exists() and RECORDS_FILE.exists():
            print("Loading cached retriever index...")
            self.embeddings = np.load(EMBEDDINGS_FILE)
            with open(RECORDS_FILE, "rb") as f:
                self.records = pickle.load(f)
            print(f"Loaded {len(self.records)} indexed Q&A pairs.")
            return

        print("Building retriever index (first run only, may take a minute)...")
        self.records = _load_qa_records()

        questions = [r["question"] for r in self.records]
        self.embeddings = self.model.encode(
            questions,
            batch_size=64,
            show_progress_bar=True,
            convert_to_numpy=True,
            normalize_embeddings=True,  # so dot product == cosine similarity
        )

        INDEX_DIR.mkdir(parents=True, exist_ok=True)
        np.save(EMBEDDINGS_FILE, self.embeddings)
        with open(RECORDS_FILE, "wb") as f:
            pickle.dump(self.records, f)

        print(f"Built and cached index with {len(self.records)} Q&A pairs.")

    def search(self, query: str, top_k: int = 3) -> List[Dict[str, str]]:
        """
        Returns the top_k most similar real Q&A pairs to the query,
        each with an added 'score' (cosine similarity, 0-1).
        """
        if not query.strip() or len(self.records) == 0:
            return []

        query_vec = self.model.encode(
            [query],
            convert_to_numpy=True,
            normalize_embeddings=True,
        )[0]

        # Cosine similarity = dot product (vectors are normalized).
        scores = self.embeddings @ query_vec

        top_indices = np.argsort(scores)[::-1][:top_k]

        results = []
        for idx in top_indices:
            record = dict(self.records[idx])
            record["score"] = float(scores[idx])
            results.append(record)

        return results
